package gurman_assign03;

import java.util.Scanner;

public class a2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,p;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		p = sc.nextInt();
		
		if(p%n==0)
			System.out.println("Yes");
		else
			System.out.println("No");
		
		
		sc.close();
	}

}
