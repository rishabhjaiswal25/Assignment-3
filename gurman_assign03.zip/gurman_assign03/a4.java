package gurman_assign03;

import java.util.Scanner;

public class a4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int suma=0,sumn=0;
		int[] arra;
		arra = new int[10];
		int[] arrn;
		arrn = new int[10];
		Scanner sc = new Scanner(System.in);
        System.out.println("Arun Dice Choice: ");
        for(int i=0;i<10;i++) {
        arra[i] = sc.nextInt();
        suma=suma+arra[i];
        }
        System.out.println("Naveen Dice Choice: ");
        for(int i=0;i<10;i++) {
        arrn[i] = sc.nextInt();
        sumn=sumn+arrn[i];
        }
		
		if(suma<sumn)
			System.out.println("Arun Wins!!! ");	
		else if(suma>sumn)
			System.out.println("Naveen Wins!!! ");	
		else
			System.out.println("Draw!!! ");	
		
		
		
		sc.close();		
	}

}
