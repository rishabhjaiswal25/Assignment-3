package ass3;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,p,k=0;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		for(int i=0;i<n;i++){
		p = sc.nextInt();
		k+=p;
		}
		
		if(k%n==0)
			System.out.println("Yes");
		else
			System.out.println("No");
		sc.close();
	}
}
