package ass3;
import java.util.Scanner;

public class Main{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        int[] arr;
        arr = new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		
		for(int i=0;i<n;i++) {
			if(arr[i]<0)
			System.out.print(arr[i]+" ");
		}
		
		for(int i=0;i<n;i++) {
			if(arr[i]>=0)
			System.out.print(arr[i]+" ");
		}
		
		sc.close();

	}

}
