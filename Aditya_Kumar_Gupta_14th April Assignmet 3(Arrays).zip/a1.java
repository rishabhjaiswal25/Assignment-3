package ass3;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,u=0,d=0;
		Scanner sc = new Scanner(System.in);
        System.out.println("Size of array :");
        n = sc.nextInt();
        int[] arr;
        arr = new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		
		Arrays.sort(arr);
		
		for(int j=0;j<n-1;j++) {
			if(arr[j]!=arr[j+1]) {
				u++;
			}
			else if(arr[j]==arr[j+1]) {
				d++;
			}
		}
		
		System.out.println("No of duplicate element: "+d);
		System.out.println("No of unique elements: "+u);
		
		sc.close();
		
	}

}
