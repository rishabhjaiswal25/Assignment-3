package ass3;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum1=0,sum2=0;
		int[] arr1;
		arr1 = new int[10];
		int[] arr2;
		arr2 = new int[10];
		Scanner sc = new Scanner(System.in);
        System.out.println("Arun Dice Choice: ");
        for(int i=0;i<10;i++) {
        arr1[i] = sc.nextInt();
        sum1=sum1+arr1[i];
        }
        System.out.println("Naveen Dice Choice: ");
        for(int i=0;i<10;i++) {
        arr2[i] = sc.nextInt();
        sum2=sum2+arr2[i];
        }
		
		if(sum1<sum2)
			System.out.println("Arun Wins!!! ");	
		else if(sum1>sum2)
			System.out.println("Naveen Wins!!! ");	
		else
			System.out.println("Draw!!! ");	
		
		
		
		sc.close();		
	}

}
